import Expenses from './components/Expenses';
import './App.css';

const expenses = [
  {
    id:'e1',
    title:'Toilet Paper',
    amount:'1.5',
    date: new Date(2020, 7, 14),
  },
  {
    id:'e2',
    title:'Car Insuranse',
    amount:200,
    date: new Date(2021, 2, 28),
  },
  {
    id:'e3',
    title:'Iphone',
    amount:1050,
    date: new Date(2021, 3, 8),
  },
  {
    id:'e4',
    title:'Cake',
    amount:50,
    date: new Date(2021, 9, 11),
  },
]

function App() {

  return (
    <div className="App">
      <Expenses items={expenses}/>
    </div>
  );
}

export default App;
